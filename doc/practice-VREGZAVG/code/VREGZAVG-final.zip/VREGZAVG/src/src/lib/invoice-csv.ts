import { minorUnitFactor } from "./money";

export interface ExportInvoice {
  invoiceNumber: string;
  company: { name: string };
  issueDate: Date | string;
  dueDate: Date | string | null;
  currencyCode: string;
  totalMinor: number;
  paidMinor: number;
  status: string;
}

const HEADER = "invoice_number,company,issue_date,due_date,currency,total,paid,outstanding,status";
function field(value: string): string {
  return /[",\r\n]/.test(value) ? `"${value.replaceAll('"', '""')}"` : value;
}
function date(value: Date | string | null): string {
  return value === null ? "" : (typeof value === "string" ? value : value.toISOString()).slice(0, 10);
}
function amount(minor: number, currency: string): string {
  const factor = minorUnitFactor(currency);
  return (minor / factor).toFixed(factor === 1 ? 0 : 2);
}

/** Input is the authenticated, filtered list in display order; never refilter statuses. */
export function invoicesToCsv(invoices: readonly ExportInvoice[]): string {
  const rows = invoices.map((invoice) => {
    const currency = invoice.currencyCode.toUpperCase();
    const outstanding = ["SENT", "PARTIAL", "OVERDUE"].includes(invoice.status)
      ? Math.max(0, invoice.totalMinor - invoice.paidMinor) : 0;
    return [invoice.invoiceNumber, invoice.company.name, date(invoice.issueDate),
      date(invoice.dueDate), currency, amount(invoice.totalMinor, currency),
      amount(invoice.paidMinor, currency), amount(outstanding, currency), invoice.status]
      .map(field).join(",");
  });
  return "\uFEFF" + [HEADER, ...rows].join("\r\n") + "\r\n";
}
