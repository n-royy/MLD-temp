import { describe, expect, it, vi } from "vitest";
import { invoicesToCsv, type ExportInvoice } from "../src/lib/invoice-csv";

vi.mock("~/server/auth", () => ({ auth: vi.fn() }));
import { accountingRouter } from "../src/server/api/routers/accounting";
import { testDb } from "./helpers";

const invoice: ExportInvoice = {
  invoiceNumber: "INV-1", company: { name: 'Công ty "Mai", Hà Nội\nBranch' },
  issueDate: new Date("2026-10-01T00:00:00Z"), dueDate: null,
  currencyCode: "USD", totalMinor: 12345, paidMinor: 2345, status: "PARTIAL",
};

describe("invoice CSV", () => {
  it("writes BOM, exact header, RFC4180 fields and UTC calendar dates", () => {
    const csv = invoicesToCsv([invoice]);
    expect(csv).toBe('\uFEFFinvoice_number,company,issue_date,due_date,currency,total,paid,outstanding,status\r\nINV-1,"Công ty ""Mai"", Hà Nội\nBranch",2026-10-01,,USD,123.45,23.45,100.00,PARTIAL\r\n');
  });
  it("preserves input order and statuses, zero decimal currencies and nonreceivables", () => {
    for (const currencyCode of ["VND", "JPY", "KRW"]) {
      const csv = invoicesToCsv(["DRAFT", "VOID", "PAID", "SENT", "OVERDUE"].map(status => ({...invoice, currencyCode, status})));
      expect(csv).toContain(`${currencyCode},12345,2345,0,DRAFT`);
      expect(csv).toContain(`${currencyCode},12345,2345,0,VOID`);
      expect(csv).toContain(`${currencyCode},12345,2345,10000,OVERDUE`);
      expect(csv.indexOf('DRAFT')).toBeLessThan(csv.indexOf('VOID'));
    }
    expect(invoicesToCsv([{...invoice, paidMinor:20000}])).toContain('123.45,200.00,0.00,PARTIAL');
  });
  it("exports an empty selection with only its header", () => {
    expect(invoicesToCsv([]).split('\r\n')).toHaveLength(2);
  });
  it("uses the company-filtered authenticated query without excluding statuses", async () => {
    const findMany = vi.fn().mockResolvedValue([{...invoice, payments:[{amountMinor:2000n},{amountMinor:345n}],subtotalMinor:12345n,taxMinor:0n,totalMinor:12345n}]);
    const caller = accountingRouter.createCaller({db:{...testDb,invoice:{findMany}} as unknown as typeof testDb,session:{user:{id:'staff'},expires:'2099-01-01'},headers:new Headers()});
    const rows = await caller.invoices({companyId:'11111111-1111-4111-8111-111111111111'});
    expect(findMany.mock.calls[0]![0].where).toEqual({companyId:'11111111-1111-4111-8111-111111111111'});
    expect(findMany.mock.calls[0]![0].orderBy).toEqual({issueDate:'desc'});
    expect(invoicesToCsv(rows)).toContain('123.45,23.45,100.00,PARTIAL');
  });
  it("rejects signed-out invoice access before querying financial data", async () => {
    const findMany=vi.fn();
    const caller=accountingRouter.createCaller({db:{...testDb,invoice:{findMany}} as unknown as typeof testDb,session:null,headers:new Headers()});
    await expect(caller.invoices({})).rejects.toMatchObject({code:'UNAUTHORIZED'});
    expect(findMany).not.toHaveBeenCalled();
  });
});
