import { minorUnitFactor } from "~/lib/money";

interface ExportInvoice {
  invoiceNumber: string;
  company: { name: string };
  issueDate: Date | string;
  dueDate: Date | string | null;
  currencyCode: string;
  totalMinor: number | bigint;
  paidMinor: number | bigint;
  status: string;
}

const HEADER = "invoice_number,company,issue_date,due_date,currency,total,paid,outstanding,status";

function csvField(value: string): string {
  return /[,"\r\n]/.test(value) ? `"${value.replaceAll('"', '""')}"` : value;
}

function amount(minor: bigint, currency: string): string {
  if (minorUnitFactor(currency) === 1) return String(minor);
  const sign = minor < 0n ? "-" : "";
  const absolute = minor < 0n ? -minor : minor;
  return `${sign}${absolute / 100n}.${String(absolute % 100n).padStart(2, "0")}`;
}

function date(value: Date | string | null): string {
  return value === null ? "" : (typeof value === "string" ? value : value.toISOString()).slice(0, 10);
}

/** Export the authenticated screen selection unchanged, including its order. */
export function invoicesToCsv(invoices: readonly ExportInvoice[]): string {
  const rows = invoices.map((invoice) => {
    const total = BigInt(invoice.totalMinor);
    const paid = BigInt(invoice.paidMinor);
    const balance = total > paid ? total - paid : 0n;
    const outstanding = ["SENT", "PARTIAL", "OVERDUE"].includes(invoice.status) ? balance : 0n;
    const currency = invoice.currencyCode.toUpperCase();
    return [
      invoice.invoiceNumber, invoice.company.name, date(invoice.issueDate), date(invoice.dueDate),
      currency, amount(total, currency), amount(paid, currency), amount(outstanding, currency), invoice.status,
    ].map(csvField).join(",");
  });
  return "\uFEFF" + [HEADER, ...rows].join("\r\n") + "\r\n";
}
