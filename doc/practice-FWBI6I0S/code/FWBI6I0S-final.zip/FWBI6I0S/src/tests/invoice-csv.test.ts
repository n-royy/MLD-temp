import { afterAll, beforeEach, describe, expect, it, vi } from "vitest";
import { invoicesToCsv } from "~/lib/invoice-csv";
import { accountingRouter } from "~/server/api/routers/accounting";
import { testDb, truncateAll } from "./helpers";

vi.mock("~/server/auth", () => ({ auth: vi.fn() }));

const base = {
  invoiceNumber: "INV-1", company: { name: "Client" },
  issueDate: new Date("2026-10-01T00:00:00Z"), dueDate: null,
  currencyCode: "USD", totalMinor: 12345, paidMinor: 2345, status: "PARTIAL",
};

describe("invoice CSV standard", () => {
  it("writes BOM, exact header, CRLF, fixed decimals and UTC calendar dates", () => {
    expect(invoicesToCsv([base])).toBe('\uFEFFinvoice_number,company,issue_date,due_date,currency,total,paid,outstanding,status\r\nINV-1,Client,2026-10-01,,USD,123.45,23.45,100.00,PARTIAL\r\n');
  });
  it("preserves Vietnamese, quotes, commas and newlines without changing text", () => {
    const company = { name: ' Công ty "Ánh Dương",\nHà Nội ' };
    expect(invoicesToCsv([{...base, company, currencyCode:'VND', paidMinor:0}]))
      .toContain('" Công ty ""Ánh Dương"",\nHà Nội ",2026-10-01,,VND,12345,0,12345,PARTIAL');
  });
  it.each(['USD','EUR','GBP','AUD','CAD','SGD'])("formats %s with two decimals", currencyCode => {
    expect(invoicesToCsv([{...base,currencyCode,totalMinor:10000,paidMinor:0}])).toContain(',100.00,0.00,100.00,PARTIAL');
  });
  it.each(['VND','JPY','KRW'])("formats %s with no decimals", currencyCode => {
    expect(invoicesToCsv([{...base,currencyCode}])).toContain(',12345,2345,10000,PARTIAL');
  });
  it.each(['DRAFT','VOID','PAID'])("keeps %s rows with zero outstanding", status => {
    expect(invoicesToCsv([{...base,status}])).toContain(`,123.45,23.45,0.00,${status}\r\n`);
  });
  it.each(['SENT','PARTIAL','OVERDUE'])("clamps overpayment for %s", status => {
    expect(invoicesToCsv([{...base,status,paidMinor:20000}])).toContain(`,123.45,200.00,0.00,${status}`);
  });
  it("exports only a header for an empty selection", () => {
    expect(invoicesToCsv([]).split('\r\n')).toHaveLength(2);
  });
  it("keeps row order and formats optional dates and negative minor units", () => {
    const csv=invoicesToCsv([{...base,invoiceNumber:'Z',totalMinor:-1,dueDate:'2026-11-01'},base]);
    expect(csv.indexOf('Z,Client')).toBeLessThan(csv.indexOf('INV-1,Client'));
    expect(csv).toContain('2026-11-01,USD,-0.01,23.45,0.00');
  });
});

describe("authenticated filtered export data source", () => {
  beforeEach(truncateAll);
  afterAll(() => testDb.$disconnect());
  const context = { db:testDb, headers:new Headers(), session:{user:{id:'staff'},expires:'2099-01-01'} };
  it("filters by company, preserves all statuses and screen order, sums payments", async () => {
    const a=await testDb.company.create({data:{name:'A',billingModel:'PER_PROJECT'}});
    const b=await testDb.company.create({data:{name:'B',billingModel:'PER_PROJECT'}});
    for (const [index,status] of ['DRAFT','VOID','SENT','PARTIAL','OVERDUE','PAID'].entries()) {
      await testDb.invoice.create({data:{companyId:a.id,invoiceNumber:`A-${index}`,issueDate:new Date(`2026-10-0${index+1}`),currencyCode:'USD',status:status as 'DRAFT',totalMinor:12345}});
    }
    await testDb.invoice.create({data:{companyId:b.id,invoiceNumber:'B',issueDate:new Date('2026-11-01'),currencyCode:'JPY'}});
    const last=await testDb.invoice.findUniqueOrThrow({where:{invoiceNumber:'A-5'}});
    await testDb.payment.createMany({data:[2000,345].map(amountMinor=>({companyId:a.id,invoiceId:last.id,amountMinor,paidAt:new Date('2026-10-08')}))});
    const caller=accountingRouter.createCaller(context);
    const selected=await caller.invoices({companyId:a.id});
    expect(selected.map(i=>i.invoiceNumber)).toEqual(['A-5','A-4','A-3','A-2','A-1','A-0']);
    expect(selected[0]?.paidMinor).toBe(2345);
    expect(invoicesToCsv(selected)).not.toContain('\r\nB,');
    expect(await caller.invoices()).toHaveLength(7);
    expect(await caller.invoices({companyId:crypto.randomUUID()})).toEqual([]);
  });
  it("rejects signed-out invoice reads before obtaining financial data", async () => {
    const caller=accountingRouter.createCaller({...context,session:null});
    await expect(caller.invoices()).rejects.toMatchObject({code:'UNAUTHORIZED'});
  });
});
