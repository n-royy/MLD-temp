import { appendPosition, betweenPosition, needsRebalance } from './src/lib/position';
import { moveCard } from './src/server/services/card';
import assert from 'node:assert/strict';

async function main() {
 const a=appendPosition(null), b=appendPosition(a), c=appendPosition(b);
 const midpoint=betweenPosition(a,b);
 assert.equal(needsRebalance(a,b),false);
 let persisted: number | undefined;
 const tx={card:{findUnique:async()=>({id:'C',listId:'list'}),update:async({data}:any)=>{persisted=data.position;return data}},list:{findUnique:async()=>({id:'list',boardId:'board'})}};
 await moveCard(tx as never,{cardId:'C',toListId:'list',position:midpoint});
 assert.equal(persisted,98304);
 console.log(JSON.stringify({initial:{A:a,B:b,C:c},neighbours:{before:a,after:b},rebalance:false,persistedC:persisted}));
}
main();
