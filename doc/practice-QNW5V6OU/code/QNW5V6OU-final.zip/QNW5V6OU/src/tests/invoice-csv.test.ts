import { describe, expect, it, vi } from "vitest";
import { invoiceCsv, type ExportInvoice } from "~/lib/invoice-csv";
vi.mock("~/server/auth", () => ({ auth: vi.fn() }));
vi.mock("~/server/db", () => ({ db: {} }));
import { accountingRouter } from "~/server/api/routers/accounting";

const invoice: ExportInvoice = {
  invoiceNumber: "INV-1", companyId: "A", company: { name: "Alpha" },
  issueDate: new Date("2026-10-01T00:00:00Z"), dueDate: null,
  currencyCode: "USD", totalMinor: 12345, paidMinor: 2345, status: "PARTIAL",
};
describe("accountant invoice CSV", () => {
  it("uses BOM, exact header, fixed decimal amounts, UTC dates and balances", () => {
    expect(invoiceCsv([invoice])).toBe('\uFEFFinvoice_number,company,issue_date,due_date,currency,total,paid,outstanding,status\r\nINV-1,Alpha,2026-10-01,,USD,123.45,23.45,100.00,PARTIAL\r\n');
  });
  it("filters without reordering or excluding statuses and exports header for empty company", () => {
    const rows=[{...invoice,status:'VOID'}, {...invoice,companyId:'B'}, {...invoice,status:'DRAFT'}];
    const csv=invoiceCsv(rows,'A');
    expect(csv.split('\r\n').slice(1,-1)).toEqual([
      'INV-1,Alpha,2026-10-01,,USD,123.45,23.45,0.00,VOID',
      'INV-1,Alpha,2026-10-01,,USD,123.45,23.45,0.00,DRAFT']);
    expect(invoiceCsv(rows,'EMPTY')).toBe(invoiceCsv([]));
  });
  it("escapes quotes, commas, CRLF and Vietnamese without changing text", () => {
    expect(invoiceCsv([{...invoice,company:{name:' Công ty "Ánh",\r\nHà Nội '}}])).toContain('" Công ty ""Ánh"",\r\nHà Nội "');
  });
  it.each(['VND','JPY','KRW'])("uses zero decimals for %s", currencyCode => {
    expect(invoiceCsv([{...invoice,currencyCode}])).toContain(`,${currencyCode},12345,2345,10000,PARTIAL`);
  });
  it.each(['SENT','PARTIAL','OVERDUE'])("clamps overpayments for %s", status=>{
    expect(invoiceCsv([{...invoice,status,paidMinor:20000}])).toContain(',123.45,200.00,0.00,');
  });
  it("preserves large integer and negative amounts without floating point or exponent notation",()=>{
    expect(invoiceCsv([{...invoice,totalMinor:-12345n,paidMinor:0n}])).toContain(',-123.45,0.00,0.00,');
    expect(invoiceCsv([{...invoice,totalMinor:900719925474099123n,paidMinor:0n}])).toContain(',9007199254740991.23,0.00,9007199254740991.23,');
  });
  it("rejects signed-out invoice queries before accessing the database",async()=>{
    const findMany=vi.fn();
    const caller=accountingRouter.createCaller({session:null,headers:new Headers(),db:{invoice:{findMany}} as never});
    await expect(caller.invoices({})).rejects.toMatchObject({code:'UNAUTHORIZED'});
    expect(findMany).not.toHaveBeenCalled();
  });
});
