import { minorUnitFactor } from "./money";

export interface ExportInvoice {
  invoiceNumber: string;
  companyId: string;
  company: { name: string };
  issueDate: Date | string;
  dueDate: Date | string | null;
  currencyCode: string;
  totalMinor: number | bigint;
  paidMinor: number | bigint;
  status: string;
}

function amount(value: number | bigint, currency: string): string {
  const minor = BigInt(value);
  const negative = minor < 0n;
  const absolute = negative ? -minor : minor;
  const factor = BigInt(minorUnitFactor(currency));
  return `${negative ? "-" : ""}${absolute / factor}${factor === 1n ? "" : `.${String(absolute % factor).padStart(2, "0")}`}`;
}

function date(value: Date | string | null): string {
  if (!value) return "";
  return typeof value === "string" ? value.slice(0, 10) : value.toISOString().slice(0, 10);
}

function escape(value: string): string {
  return /[",\r\n]/.test(value) ? `"${value.replaceAll('"', '""')}"` : value;
}

/** KB-EXP-01, FIN-01/04, AR-02 and INV-03. Preserve selection order and text. */
export function invoiceCsv(invoices: readonly ExportInvoice[], companyId?: string): string {
  const rows = invoices.filter((i) => !companyId || i.companyId === companyId).map((i) => {
    const total = BigInt(i.totalMinor);
    const paid = BigInt(i.paidMinor);
    const balance = ["SENT", "PARTIAL", "OVERDUE"].includes(i.status) && total > paid ? total - paid : 0n;
    const currency = i.currencyCode.toUpperCase();
    return [i.invoiceNumber, i.company.name, date(i.issueDate), date(i.dueDate), currency,
      amount(total, currency), amount(paid, currency), amount(balance, currency), i.status].map(escape).join(",");
  });
  return "\uFEFF" + ["invoice_number,company,issue_date,due_date,currency,total,paid,outstanding,status", ...rows].join("\r\n") + "\r\n";
}
