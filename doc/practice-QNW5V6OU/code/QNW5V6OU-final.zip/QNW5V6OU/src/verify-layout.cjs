const {chromium}=require('playwright');
const fs=require('fs');
(async()=>{
 const b=await chromium.launch({headless:true,channel:'msedge'});
 const p=await b.newPage({viewport:{width:1440,height:1000}});
 const base=process.env.APP_ORIGIN||'http://localhost:3000';
 await p.goto(base+'/login');
 await p.getByLabel('Username or email').fill('morpheusadam95');
 await p.getByLabel('Password').fill('change-me-please');
 await p.getByRole('button',{name:'Sign in',exact:true}).click();
 await p.waitForURL('**/dashboard');
 await p.getByRole('heading',{name:'Dashboard',exact:true}).waitFor();
 await p.waitForTimeout(1000);
 await p.screenshot({path:'../answers/BUG-01/evidence/'+(process.env.BEFORE?'dashboard_before_fixing.png':'tc-01-desktop-dashboard.png'),fullPage:true});
 if(!process.env.BEFORE){
  const results=[];
  async function desktop(width,path){
   await p.setViewportSize({width,height:1000});await p.goto(base+path);
   await p.locator('main h1').waitFor();await p.waitForTimeout(700);
   const rect=await p.evaluate(()=>{const box=s=>{const r=document.querySelector(s).getBoundingClientRect();return {left:r.left,right:r.right,width:r.width}};return {sidebar:box('nav'),main:box('main'),topbar:box('header')}});
   if(rect.main.left<rect.sidebar.right||rect.topbar.left<rect.sidebar.right)throw Error('Sidebar overlap '+JSON.stringify(rect));
   results.push({width,path,...rect});
  }
  await desktop(1440,'/dashboard');
  if(process.env.PRODUCTION){
   await desktop(1024,'/accounting');await p.screenshot({path:'../answers/BUG-01/evidence/tc-02-production-layout.png',fullPage:true});
   await desktop(1024,'/boards');await p.screenshot({path:'../answers/BUG-01/evidence/tc-02-production-boards.png',fullPage:true});
  }
  await p.setViewportSize({width:390,height:844});await p.goto(base+'/dashboard');
  await p.locator('main h1').waitFor();
  await p.getByRole('link',{name:'Money',exact:true}).click();await p.waitForURL('**/accounting');
  await p.getByRole('heading',{name:'Accounting',exact:true}).waitFor();
  await p.screenshot({path:'../answers/BUG-01/evidence/tc-03-mobile-accounting.png',fullPage:true});
  await p.getByRole('link',{name:'Home',exact:true}).click({position:{x:70,y:10}});await p.waitForURL('**/dashboard');
  await p.getByRole('heading',{name:'Dashboard',exact:true}).waitFor();await p.waitForTimeout(500);
  await p.screenshot({path:'../answers/BUG-01/evidence/tc-03-mobile-dashboard.png',fullPage:true});
  const mobile=await p.evaluate(()=>({mainLeft:document.querySelector('main').getBoundingClientRect().left,desktopSidebarHidden:getComputedStyle(document.querySelector('nav')).display==='none'}));
  if(!mobile.desktopSidebarHidden||mobile.mainLeft!==0)throw Error('Mobile layout regression');
  results.push({width:390,navigation:'Money and Home links passed',...mobile});
  fs.writeFileSync('../answers/BUG-01/evidence/'+(process.env.PRODUCTION?'production-layout.json':'development-layout.json'),JSON.stringify(results,null,2));
 }
 await b.close();
})().catch(e=>{console.error(e);process.exit(1)});

