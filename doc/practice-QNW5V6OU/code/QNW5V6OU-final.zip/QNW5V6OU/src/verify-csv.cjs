const {chromium}=require('playwright');const fs=require('fs');
(async()=>{
 const b=await chromium.launch({headless:true,channel:'msedge'});
 const p=await b.newPage({viewport:{width:1440,height:1000},acceptDownloads:true});
 const out='../answers/CR-01/evidence/';const fixture=JSON.parse(fs.readFileSync(out+'cr-01-test-data.json','utf8'));
 await p.goto('http://localhost:3000/login');await p.getByLabel('Username or email').fill('morpheusadam95');await p.getByLabel('Password').fill('change-me-please');await p.getByRole('button',{name:'Sign in',exact:true}).click();await p.waitForURL('**/dashboard');
 await p.goto('http://localhost:3000/accounting');await p.getByRole('tab',{name:'Invoices',exact:true}).click();await p.getByText('CR01-MLD-0005',{exact:true}).waitFor();
 await p.screenshot({path:out+(process.env.BEFORE?'before-invoices.png':'after-invoices.png'),fullPage:true});
 if(!process.env.BEFORE){
  for(const [key,name] of [['ALL','tc-01-all-invoices'],['A','tc-02-filtered-invoices'],['VN','tc-03-special-company'],['EMPTY','tc-05-empty-export']]){
   await p.getByRole('combobox',{name:'Filter by company'}).click();
   const company=key==='ALL'?'All companies':fixture.data.companies.find(c=>c.key===key).name;
   await p.getByRole('option',{name:company,exact:true}).click();
   await p.waitForTimeout(700);
   const d=p.waitForEvent('download');await p.getByRole('button',{name:'Export CSV',exact:true}).click();await (await d).saveAs(out+name+'.csv');
   await p.screenshot({path:out+name+'.png',fullPage:true});
  }
  const anon=await b.newPage({viewport:{width:1440,height:1000}});await anon.goto('http://localhost:3000/accounting');await anon.getByRole('button',{name:'Sign in',exact:true}).waitFor();await anon.screenshot({path:out+'tc-04-signed-out.png',fullPage:true});
 }
 await b.close();
})().catch(e=>{console.error(e);process.exit(1)});
